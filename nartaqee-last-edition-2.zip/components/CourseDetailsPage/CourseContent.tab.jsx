"use client";

import React, { useState } from "react";
import {
  CourseChevronTopIcon,
  CourseLockIcon,
  CoursePlayIcon,
} from "../../public/svgs";
import CourseContentDrawer from "../ui/CourseContentDrawer";
import Link from "next/link";

const CourseContent = ({ isRegistered }) => {
  const [selectedTab, setSelectedTab] = useState("foundation");

  return (
    // The w-full and flex-1 classes are already responsive.
    <div className="w-full flex-1">
      {/* Responsive font size and margin for the title */}
      <div className="text-right justify-center text-primary text-lg md:text-2xl font-bold mb-6 lg:mb-8">
        محتوي الدورة : إتقان التدريس الفعال
      </div>

      {isRegistered && (
        <Navs selectedTab={selectedTab} setSelectedTab={setSelectedTab} />
      )}

      {/* The content sections below are already structured to be responsive */}
      {selectedTab == "foundation" && (
        <div className="flex flex-col gap-3 md:gap-4">
          <CourseContentDrawer isRegistered={isRegistered} />
          <CourseContentDrawer isRegistered={isRegistered} />
          <CourseContentDrawer isRegistered={isRegistered} />
        </div>
      )}

      {selectedTab == "lectures" && (
        <div className="flex flex-col gap-3 md:gap-4">
          <CourseContentDrawer isRegistered={isRegistered} />
          <CourseContentDrawer isRegistered={isRegistered} />
          <CourseContentDrawer isRegistered={isRegistered} />
        </div>
      )}

      {selectedTab == "tests" && (
        <div className="flex flex-col gap-3 md:gap-4">
          <TestRow />
          <TestRow />
          <TestRow />
          <TestRow />
        </div>
      )}
    </div>
  );
};

export default CourseContent;

export const Navs = ({ selectedTab, setSelectedTab }) => {
  const tabsData = [
    { id: "foundation", label: "مرحلة التأسيس" },
    { id: "lectures", label: "المحاضرات" },
    { id: "tests", label: "اختبارات" },
  ];

  const handleTabClick = (tabId) => {
    setSelectedTab(tabId);
  };

  return (
    <nav
      // w-full on mobile, fixed width on desktop. Responsive padding and rounding.
      className="flex w-full lg:w-[762px] mb-6 items-center justify-between p-2 lg:p-4 relative bg-[#ebf3fe] rounded-[20px] lg:rounded-[30px]"
      role="tablist"
    >
      {tabsData.map((tab) => (
        <button
          key={tab.id}
          // flex-1 for equal width on mobile, original widths restored on desktop.
          className={`flex-1 lg:flex-none justify-center rounded-[16px] lg:rounded-[20px] items-center px-3 py-3 lg:px-6 lg:py-4 relative transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-300 
            ${tab.id === "tests" ? "lg:w-[195px]" : "lg:inline-flex"} 
            ${selectedTab === tab.id ? "bg-primary font-bold" : ""}`}
          onClick={() => handleTabClick(tab.id)}
          role="tab"
          aria-selected={selectedTab === tab.id}
        >
          <span
            // Responsive font size
            className={`w-fit text-center text-sx  md:text-lg lg:text-2xl leading-normal
              ${selectedTab === tab.id ? "text-white" : "text-zinc-500"}`}
          >
            {tab.label}
          </span>
        </button>
      ))}
    </nav>
  );
};

export const TestRow = () => {
  // SVG components (ChevronLeft, TestIcon) are not changed.

  return (
    <Link
      href={"/mock-test/123"}
      // Stacks vertically on mobile, row on desktop. Responsive padding.
      className="flex flex-col lg:flex-row items-start lg:items-center group hover:shadow-2xl cursor-pointer duration-75 transition-all justify-between p-4 lg:px-6 lg:py-8 relative bg-white rounded-[20px] border-2 border-solid border-zinc-500 gap-4"
    >
      {/* Test Title section */}
      <div className="flex items-center gap-3">
        <TestIcon />
        <p className="group-hover:text-primary transition-all duration-75 font-medium text-text text-sm md:text-base">
          الأختبار الأول : مدخل إلى التدريس الفعال
        </p>
      </div>

      {/* Test Type and Chevron section */}
      {/* justify-between pushes chevron to the end on mobile */}
      <div className="w-full lg:w-auto flex items-center justify-between lg:justify-start lg:gap-4">
        <div className="font-bold text-primary text-base lg:text-lg">
          ( اختبار محاكي )
        </div>
        <div className="relative w-6 h-6">
          <ChevronLeft />
        </div>
      </div>
    </Link>
  );
};
