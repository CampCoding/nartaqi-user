"use client";

import React, { useState } from "react";
import CourseBriefOverview from "./CourseBriefOverview.tab";
import CourseContent from "./CourseContent.tab";
import CourseAdvantages from "./CourseAdvantages.tab";
import CourseTermsAndConditions from "./CourseTermsAndConditions";
import CourseRatings from "./CourseRatings.tab";

const RegCourseDetailsContent = () => {
  const [activeTab, setActiveTab] = useState("overview");

  const tabs = [
    { label: "معلومات الدورة", value: "overview" },
    { label: " محتوى الدورة", value: "content" },
    { label: "مصادر الدورة", value: "features" },

  ];

  return (
    <div className="flex flex-col gap-[56px]">
      <div className="w-[762px] inline-flex justify-between items-center">
        {tabs.map((tab) => (
          <div
            key={tab.value}
            onClick={() => setActiveTab(tab.value)}
            className={`flex justify-center items-center gap-2.5 cursor-pointer ${
              activeTab === tab.value ? "border-b-[3px] border-primary" : ""
            }`}
          >
            <div
              className={`text-right justify-center text-2xl  ${
                activeTab === tab.value
                  ? "text-primary font-bold"
                  : "text-text font-medium"
              }`}
            >
              {tab.label}
            </div>
          </div>
        ))}
      </div>
      <div className="w-[762px]">
        {activeTab === "overview" && <CourseBriefOverview isRegistered />}
        {activeTab === "content" && <CourseContent isRegistered />}
        {activeTab === "features" && <CourseAdvantages />}
        {activeTab === "terms" && <CourseTermsAndConditions />}
        {activeTab === "reviews" && <CourseRatings />} 
      
      </div>
    </div>
  );
};

export default RegCourseDetailsContent;
