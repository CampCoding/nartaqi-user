import React from "react";
import { RatingStarIcon } from "../../../public/svgs";

const LicturerCard = () => {
  return (
    <article className="inline-flex flex-col items-center gap-6 p-12 relative bg-white rounded-[30px] border-2 border-solid border-[#909dad]">
      <div
        className="relative w-[124px] h-[124px] rounded-[62px] bg-[url(/images/Image-12422.png)] bg-cover bg-[50%_50%]"
        role="img"
        aria-label="خالد عبد الرحمن يوسف profile picture"
      />

      <div className="inline-flex flex-col items-center gap-4 relative flex-[0_0_auto]">
        <header className="flex flex-col items-center self-stretch w-full relative flex-[0_0_auto]">
          <h1 className="self-stretch mt-[-1.00px]  font-bold text-text text-xl text-center relative flex items-center justify-center tracking-[0] leading-[normal] [direction:rtl]">
            خالد عبد الرحمن يوسف
          </h1>

          <p className="w-fit  text-[16px] font-medium text-text-alt text-base text-center relative flex items-center justify-center tracking-[0] leading-[normal] [direction:rtl]">
            محاضر في إتقان التدريس الفعال
          </p>
        </header>

        <div className="inline-flex flex-col items-center gap-2 relative flex-[0_0_auto]">
          <div
            className="inline-flex items-center gap-2 relative flex-[0_0_auto]"
            role="group"
            aria-label="Rating information"
          >
            <div className="relative flex items-center justify-center w-fit mt-[-1.00px]  font-medium text-text-duplicate text-xl tracking-[0] leading-[normal]">
              <span aria-label="Rating 4.5 out of 5 stars with 1450 reviews">
                4.5 (1450)
              </span>
            </div>
            <RatingStarIcon className="w-[20px] h-[20px]" />
          </div>

          <nav aria-label="Social media links " className="flex items-center gap-[6px]">
            <button
              className="flex flex-col w-12 h-12 items-center justify-center gap-2.5 p-2 relative bg-white rounded-[50px] overflow-hidden border border-solid border-blue-500 cursor-pointer hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors duration-200"
              type="button"
              aria-label="Facebook social media link"
            >
              <div className="absolute top-[calc(50.00%_-_20px)] left-[calc(50.00%_-_20px)] w-10 h-10 bg-[#d7e6ff] rounded-[20px] aspect-[1]" />

              <div className="relative w-5 h-5">
                <InstagramIcon />
              </div>
            </button>
            <button
              className="flex flex-col w-12 h-12 items-center justify-center gap-2.5 p-2 relative bg-white rounded-[50px] overflow-hidden border border-solid border-blue-500 cursor-pointer hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors duration-200"
              type="button"
              aria-label="Facebook social media link"
            >
              <div className="absolute top-[calc(50.00%_-_20px)] left-[calc(50.00%_-_20px)] w-10 h-10 bg-[#d7e6ff] rounded-[20px] aspect-[1]" />

              <div className="relative w-5 h-5">
                <LinkedInIcon />
              </div>
            </button>

            <button
              className="flex flex-col w-12 h-12 items-center justify-center gap-2.5 p-2 relative bg-white rounded-[50px] overflow-hidden border border-solid border-blue-500 cursor-pointer hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors duration-200"
              type="button"
              aria-label="Facebook social media link"
            >
              <div className="absolute top-[calc(50.00%_-_20px)] left-[calc(50.00%_-_20px)] w-10 h-10 bg-[#d7e6ff] rounded-[20px] aspect-[1]" />

              <div className="relative w-5 h-5">
                <FacebookIcon />
              </div>
            </button>
          </nav>
        </div>
      </div>
    </article>
  );
};

export default LicturerCard;

export const FacebookIcon = (props) => (
  <svg
    width={20}
    height={20}
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <path
      d="M10 0.0390625C4.5 0.0390625 0 4.52906 0 10.0591C0 15.0591 3.66 19.2091 8.44 19.9591V12.9591H5.9V10.0591H8.44V7.84906C8.44 5.33906 9.93 3.95906 12.22 3.95906C13.31 3.95906 14.45 4.14906 14.45 4.14906V6.61906H13.19C11.95 6.61906 11.56 7.38906 11.56 8.17906V10.0591H14.34L13.89 12.9591H11.56V19.9591C13.9164 19.5869 16.0622 18.3846 17.6099 16.5691C19.1576 14.7537 20.0054 12.4447 20 10.0591C20 4.52906 15.5 0.0390625 10 0.0390625Z"
      fill="#3B82F6"
    />
  </svg>
);

const LinkedInIcon = (props) => (
  <svg
    width={18}
    height={18}
    viewBox="0 0 18 18"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <path
      d="M16 0C16.5304 0 17.0391 0.210714 17.4142 0.585786C17.7893 0.960859 18 1.46957 18 2V16C18 16.5304 17.7893 17.0391 17.4142 17.4142C17.0391 17.7893 16.5304 18 16 18H2C1.46957 18 0.960859 17.7893 0.585786 17.4142C0.210714 17.0391 0 16.5304 0 16V2C0 1.46957 0.210714 0.960859 0.585786 0.585786C0.960859 0.210714 1.46957 0 2 0H16ZM15.5 15.5V10.2C15.5 9.33539 15.1565 8.5062 14.5452 7.89483C13.9338 7.28346 13.1046 6.94 12.24 6.94C11.39 6.94 10.4 7.46 9.92 8.24V7.13H7.13V15.5H9.92V10.57C9.92 9.8 10.54 9.17 11.31 9.17C11.6813 9.17 12.0374 9.3175 12.2999 9.58005C12.5625 9.8426 12.71 10.1987 12.71 10.57V15.5H15.5ZM3.88 5.56C4.32556 5.56 4.75288 5.383 5.06794 5.06794C5.383 4.75288 5.56 4.32556 5.56 3.88C5.56 2.95 4.81 2.19 3.88 2.19C3.43178 2.19 3.00193 2.36805 2.68499 2.68499C2.36805 3.00193 2.19 3.43178 2.19 3.88C2.19 4.81 2.95 5.56 3.88 5.56ZM5.27 15.5V7.13H2.5V15.5H5.27Z"
      fill="#3B82F6"
    />
  </svg>
);

const InstagramIcon = (props) => (
  <svg
    width={20}
    height={20}
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <path
      d="M10.001 7C9.20535 7 8.44229 7.31607 7.87968 7.87868C7.31707 8.44129 7.001 9.20435 7.001 10C7.001 10.7956 7.31707 11.5587 7.87968 12.1213C8.44229 12.6839 9.20535 13 10.001 13C10.7966 13 11.5597 12.6839 12.1223 12.1213C12.6849 11.5587 13.001 10.7956 13.001 10C13.001 9.20435 12.6849 8.44129 12.1223 7.87868C11.5597 7.31607 10.7966 7 10.001 7ZM10.001 5C11.3271 5 12.5989 5.52678 13.5365 6.46447C14.4742 7.40215 15.001 8.67392 15.001 10C15.001 11.3261 14.4742 12.5979 13.5365 13.5355C12.5989 14.4732 11.3271 15 10.001 15C8.67492 15 7.40315 14.4732 6.46547 13.5355C5.52778 12.5979 5.001 11.3261 5.001 10C5.001 8.67392 5.52778 7.40215 6.46547 6.46447C7.40315 5.52678 8.67492 5 10.001 5ZM16.501 4.75C16.501 5.08152 16.3693 5.39946 16.1349 5.63388C15.9005 5.8683 15.5825 6 15.251 6C14.9195 6 14.6015 5.8683 14.3671 5.63388C14.1327 5.39946 14.001 5.08152 14.001 4.75C14.001 4.41848 14.1327 4.10054 14.3671 3.86612C14.6015 3.6317 14.9195 3.5 15.251 3.5C15.5825 3.5 15.9005 3.6317 16.1349 3.86612C16.3693 4.10054 16.501 4.41848 16.501 4.75ZM10.001 2C7.527 2 7.123 2.007 5.972 2.058C5.188 2.095 4.662 2.2 4.174 2.39C3.76583 2.54037 3.39672 2.78063 3.094 3.093C2.78127 3.39562 2.54066 3.76474 2.39 4.173C2.2 4.663 2.095 5.188 2.059 5.971C2.007 7.075 2 7.461 2 10C2 12.475 2.007 12.878 2.058 14.029C2.095 14.812 2.2 15.339 2.389 15.826C2.559 16.261 2.759 16.574 3.091 16.906C3.428 17.242 3.741 17.443 4.171 17.609C4.665 17.8 5.191 17.906 5.971 17.942C7.075 17.994 7.461 18 10 18C12.475 18 12.878 17.993 14.029 17.942C14.811 17.905 15.337 17.8 15.826 17.611C16.2342 17.4606 16.6033 17.2204 16.906 16.908C17.243 16.572 17.444 16.259 17.61 15.828C17.8 15.336 17.906 14.81 17.942 14.028C17.994 12.925 18 12.538 18 10C18 7.526 17.993 7.122 17.942 5.971C17.905 5.189 17.799 4.661 17.61 4.173C17.4596 3.76483 17.2194 3.39572 16.907 3.093C16.6044 2.78027 16.2353 2.53966 15.827 2.389C15.337 2.199 14.811 2.094 14.029 2.058C12.926 2.006 12.54 2 10 2M10 0C12.717 0 13.056 0.00999994 14.123 0.0599999C15.187 0.11 15.913 0.277 16.55 0.525C17.21 0.779 17.766 1.123 18.322 1.678C18.8307 2.17773 19.2242 2.78247 19.475 3.45C19.722 4.087 19.89 4.813 19.94 5.878C19.987 6.944 20 7.283 20 10C20 12.717 19.99 13.056 19.94 14.122C19.89 15.188 19.722 15.912 19.475 16.55C19.2242 17.2175 18.8307 17.8223 18.322 18.322C17.8223 18.8307 17.2175 19.2242 16.55 19.475C15.913 19.722 15.187 19.89 14.123 19.94C13.056 19.987 12.717 20 10 20C7.283 20 6.944 19.99 5.877 19.94C4.813 19.89 4.088 19.722 3.45 19.475C2.78247 19.2242 2.17773 18.8307 1.678 18.322C1.16931 17.8223 0.775816 17.2175 0.525 16.55C0.277 15.913 0.11 15.187 0.0599999 14.122C0.0119999 13.056 0 12.717 0 10C0 7.283 0.00999994 6.944 0.0599999 5.878C0.11 4.812 0.277 4.088 0.525 3.45C0.775816 2.78247 1.16931 2.17773 1.678 1.678C2.17773 1.16931 2.78247 0.775816 3.45 0.525C4.087 0.277 4.812 0.11 5.877 0.0599999C6.945 0.0129999 7.284 0 10.001 0"
      fill="#3B82F6"
    />
  </svg>
);
