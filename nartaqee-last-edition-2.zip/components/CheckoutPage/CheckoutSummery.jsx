import React, { useState } from "react";

const CheckoutSummery = () => {
  const [couponCode, setCouponCode] = useState("");

  const orderSummaryData = {
    title: "ملخص الطلب",
    subtotal: { label: "المجموع الفرعي", amount: "475 ر.س" },
    discount: { label: "الخصم", amount: "- 50 ر.س" },
    total: { label: "المجموع", amount: "425 ر.س" },
    coupon: {
      title: "إضافة كوبون",
      placeholder: "كود كوبون",
      buttonText: "إستخدام",
    },
  };

  const handleCouponSubmit = (e) => {
    e.preventDefault();
    console.log("Applying coupon:", couponCode);
  };

  const handleCouponChange = (e) => {
    setCouponCode(e.target.value);
  };

  return (
    <section
      dir="rtl"
      className="flex flex-col items-start gap-3 sm:gap-4 pt-6 md:pt-8 pb-10 md:pb-12 px-4 sm:px-6 md:px-8 bg-white rounded-[30px] border-[3px] border-solid border-variable-collection-stroke w-full"
      aria-label="ملخص الطلب"
    >
      {/* Title */}
      <header className="font-bold text-text text-2xl md:text-[32px] leading-normal">
        {orderSummaryData.title}
      </header>

      {/* Subtotal */}
      <div className="flex items-center justify-between w-full">
        <span className="font-semibold text-text-alt text-sm md:text-base">
          {orderSummaryData.subtotal.label}
        </span>
        <span className="font-bold text-text-alt text-sm md:text-base">
          {orderSummaryData.subtotal.amount}
        </span>
      </div>

      {/* Discount */}
      <div className="flex items-center justify-between w-full">
        <span className="font-semibold text-text-alt text-sm md:text-base">
          {orderSummaryData.discount.label}
        </span>
        <span className="font-bold text-secondary text-sm md:text-base">
          {orderSummaryData.discount.amount}
        </span>
      </div>

      {/* Total */}
      <div className="flex items-center justify-between w-full border-t-[3px] border-variable-collection-stroke pt-3 md:pt-4">
        <span className="font-bold text-secondary text-xl md:text-2xl">
          {orderSummaryData.total.label}
        </span>
        <span className="font-bold text-secondary text-xl md:text-2xl">
          {orderSummaryData.total.amount}
        </span>
      </div>

      {/* Coupon */}
      <div className="flex flex-col gap-1.5 md:gap-2 w-full">
        <h3 className="font-bold text-text text-sm md:text-base">
          {orderSummaryData.coupon.title}
        </h3>

        <form
          onSubmit={handleCouponSubmit}
          className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 md:gap-6 w-full"
        >
          {/* Input */}
          <label htmlFor="coupon" className="sr-only">
            {orderSummaryData.coupon.placeholder}
          </label>
          <div className="flex justify-end gap-3 px-3 md:px-4 py-3.5 md:py-6 bg-white rounded-[20px] border border-solid border-zinc-500 w-full focus-within:border-secondary focus-within:ring-2 focus-within:ring-secondary/20">
            <input
              id="coupon"
              type="text"
              value={couponCode}
              onChange={handleCouponChange}
              placeholder={orderSummaryData.coupon.placeholder}
              className="w-full font-bold text-zinc-500 text-sm md:text-base placeholder:text-zinc-500 outline-none"
              autoComplete="off"
              inputMode="text"
            />
          </div>

          {/* Button */}
          <button
            type="submit"
            className="flex w-full sm:w-[191px] items-center justify-center gap-2.5 px-5 md:px-6 py-3.5 md:py-4 bg-secondary hover:bg-secondary-dark cursor-pointer rounded-[20px] focus:outline-none focus:ring-2 focus:ring-secondary focus:ring-offset-2 transition-colors duration-200"
            aria-label="تطبيق الكوبون"
          >
            <span className="font-bold text-white text-sm md:text-base leading-normal">
              {orderSummaryData.coupon.buttonText}
            </span>
          </button>
        </form>
      </div>
    </section>
  );
};

export default CheckoutSummery;
