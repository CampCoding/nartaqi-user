import React from "react";
import { ProfileSideBar } from "../../../components/profile/ProfileSideBar";
import ProfileData from "../../../components/profile/ProfileData";

const Profile = () => {
  return <ProfileData />;
};

export default Profile;
